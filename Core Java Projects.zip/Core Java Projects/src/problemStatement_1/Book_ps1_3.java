package problemStatement_1;

public class Book_ps1_3 {
	private String bookTitle;
    private int bookPrice;
    
    
    public void setBookTitle(String bookTitle)
    {
        this.bookTitle=bookTitle;
    }
    
    public String getBookTitle()
    {
        return this.bookTitle;
    }
    
    public void setBookPrice(int bookPrice)
    {
        this.bookPrice=bookPrice;
    }
    
    public int getBookPrice()
    {
        return this.bookPrice;
    }

}
