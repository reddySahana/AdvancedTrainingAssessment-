package problemStatement_3;


public abstract class Ps3_1Instrument {
	
	public abstract void Play();
	
	    }