package problemStatement_8;

public class Ps8_1ThreadCounter {

	public static void main(String args[])

	{

	Counte counter = new Counte(25);

	counter.run();

	}
}
